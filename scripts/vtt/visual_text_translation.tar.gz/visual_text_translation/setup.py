from setuptools import setup, find_packages

setup(
    name='visual-text-translation',
    version='1.0.0',
    description='End-to-end Telugu scene text detection, translation and inpainting',
    packages=find_packages(),
    python_requires='>=3.10',
    install_requires=[
        'torch>=2.0.0',
        'torchvision>=0.15.0',
        'opencv-python>=4.8.0',
        'easyocr>=1.7.0',
        'numpy>=1.24.0',
        'Pillow>=10.0.0',
        'scikit-image>=0.21.0',
        'shapely>=2.0.0',
        'matplotlib>=3.7.0',
        'requests>=2.31.0',
        'sarvamai>=0.1.0',
        'gdown>=4.7.0',
    ],
)
